package com.thecreator;

import com.mojang.serialization.Codec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(TheCreatorMod.ID)
public class TheCreatorMod {
    public static final String ID = "thecreator";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ID);
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, ID);

    public static final RegistryObject<EntityType<CreatorEntity>> CREATOR = ENTITIES.register("creator",
            () -> EntityType.Builder.of(CreatorEntity::new, MobCategory.MISC)
                    .sized(1.25F, 5.0F).clientTrackingRange(10).fireImmune().build("creator"));

    public static final RegistryObject<SoundEvent> NAME_CALL = sound("name_call");
    public static final RegistryObject<SoundEvent> BUILD_ACK = sound("build_ack");
    public static final RegistryObject<SoundEvent> YES = sound("yes");
    public static final RegistryObject<SoundEvent> NO = sound("no");
    public static final RegistryObject<SoundEvent> BREAK_SPEECH = sound("break_speech");
    public static final RegistryObject<SoundEvent> DREAM_SPEECH = sound("dream_speech");
    public static final RegistryObject<SoundEvent> ROAR = sound("roar");

    private static RegistryObject<SoundEvent> sound(String n) {
        return SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ID, n)));
    }

    public TheCreatorMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        SOUNDS.register(bus);
        LOOT.register(bus);
        LOOT.register("add_rule_book", RuleBookModifier.CODEC);
        bus.addListener(this::attributes);
        bus.addListener((FMLCommonSetupEvent e) -> Net.init());
        MinecraftForge.EVENT_BUS.register(new ServerEvents());
    }

    private void attributes(EntityAttributeCreationEvent e) {
        e.put(CREATOR.get(), CreatorEntity.attributes().build());
    }
}
