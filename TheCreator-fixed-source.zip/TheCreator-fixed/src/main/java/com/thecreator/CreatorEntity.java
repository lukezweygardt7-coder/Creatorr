package com.thecreator;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreakDoorGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

public class CreatorEntity extends PathfinderMob {
    public static final int IDLE = 0, SPEAK_BREAK = 1, LEAVE = 2, CHASE = 3, DREAM = 4;
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(CreatorEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> GLITCH = SynchedEntityData.defineId(CreatorEntity.class, EntityDataSerializers.INT);

    private boolean seen;
    private int unseenTicks, speechTicks, leaveTicks, roarTicks;
    private BlockPos waterTarget;

    public CreatorEntity(EntityType<? extends CreatorEntity> type, Level level) {
        super(type, level);
        this.setMaxUpStep(1.0F);                       // steps over blocks
        this.setInvulnerable(true);                    // ordinary damage cannot affect The Creator
        ((GroundPathNavigation) getNavigation()).setCanOpenDoors(true);
        ((GroundPathNavigation) getNavigation()).setCanPassDoors(true);
        this.setPersistenceRequired();
    }

    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder attributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 200.0)
                .add(Attributes.MOVEMENT_SPEED, 0.2)      // roughly twice a walking player
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(STATE, IDLE);
        entityData.define(GLITCH, 0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new OpenDoorGoal(this, false));
        goalSelector.addGoal(2, new BreakDoorGoal(this, 40, d -> true));   // breaks doors in chases
        goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.7, true) {
            @Override public boolean canUse() { return getState() == CHASE && super.canUse(); }
            @Override public boolean canContinueToUse() { return getState() == CHASE && super.canContinueToUse(); }
        });
    }

    public int getState() { return entityData.get(STATE); }
    public void setState(int s) { entityData.set(STATE, s); }
    public int getGlitch() { return entityData.get(GLITCH); }

    // The source model is 80 Blockbench units tall (5 Minecraft blocks), so its
    // eye point and entity bounds must match the rendered mesh.
    @Override protected float getStandingEyeHeight(Pose pose, EntityDimensions dim) { return 4.6F; }

    // Make the entity immune to every normal damage source, including attacks,
    // projectiles, fire, explosions, and environmental damage.
    @Override public boolean isInvulnerableTo(DamageSource source) { return true; }

    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    // ---------- behaviours ----------
    public void startBreakSpeech() {
        setState(SPEAK_BREAK);
        speechTicks = 270;                              // ~12.6 s clip + a moment
        playVoice(TheCreatorMod.BREAK_SPEECH.get());
    }

    public void startChase(Player p) {
        setState(CHASE);
        setTarget(p);
        roarTicks = 0;
        playVoice(TheCreatorMod.ROAR.get());
    }

    public void playVoice(SoundEvent e) {
        level().playSound(null, getX(), getY(), getZ(), e, SoundSource.NEUTRAL, 3.0F, 1.0F);
    }

    /** True when the player is facing him with a clear line of sight. */
    public boolean isLookedAtBy(Player p) {
        Vec3 to = getEyePosition().subtract(p.getEyePosition()).normalize();
        return p.getViewVector(1.0F).dot(to) > 0.8 && p.hasLineOfSight(this);
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        // Attacks may provoke him, but never deal damage or reduce his health.
        if (!level().isClientSide && src.getEntity() instanceof ServerPlayer p && getState() != DREAM) startChase(p);
        return false;
    }

    // Block the normal KILLED removal path (including /kill), while still allowing
    // the mod's intentional discard/vanish behavior.
    @Override
    public void remove(net.minecraft.world.entity.Entity.RemovalReason reason) {
        if (reason == net.minecraft.world.entity.Entity.RemovalReason.KILLED) return;
        super.remove(reason);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;
        int g = getGlitch();
        if (g > 0) entityData.set(GLITCH, g - 1);
        int st = getState();
        if (st == DREAM) { getNavigation().stop(); return; }

        Player near = level().getNearestPlayer(this, 128);
        if (near == null) { discard(); return; }
        if (st != CHASE) setTarget(null);
        getLookControl().setLookAt(near, 40F, 40F);      // head always follows the player

        boolean watched = false;
        for (Player p : level().players()) if (distanceToSqr(p) < 64 * 64 && isLookedAtBy(p)) { watched = true; break; }
        if (watched) {
            if (!seen) { seen = true; entityData.set(GLITCH, 14); }   // the "switchy" moment
            unseenTicks = 0;
        } else unseenTicks++;

        switch (st) {
            case IDLE -> {
                getNavigation().stop();
                if ((seen && unseenTicks > 4) || (!seen && unseenTicks > 600)) vanish(false);
            }
            case SPEAK_BREAK -> {
                getNavigation().stop();
                if (--speechTicks <= 0) setState(LEAVE);     // cannot vanish while talking
            }
            case LEAVE -> tickLeave();
            case CHASE -> { if (++roarTicks % 150 == 0) playVoice(TheCreatorMod.ROAR.get());
                if (distanceToSqr(near) > 80 * 80 && ++leaveTicks > 200) vanish(false); }
            default -> {}
        }
    }

    private void tickLeave() {
        ServerLevel sl = (ServerLevel) level();
        CreatorData d = CreatorData.get(sl.getServer());
        if (waterTarget == null) {
            BlockPos o = d.houseOrigin;
            Optional<BlockPos> w = BlockPos.findClosestMatch(blockPosition(), 64, 24, p ->
                    sl.getFluidState(p).is(FluidTags.WATER) && sl.getFluidState(p).isSource() && !HouseBuilder.insideHouse(d, p));
            if (w.isPresent()) waterTarget = w.get();
            else {                                         // no water nearby: just walk off
                Vec3 dir = new Vec3(getX() - o.getX(), 0, getZ() - o.getZ()).normalize().scale(40);
                waterTarget = BlockPos.containing(getX() + dir.x, getY(), getZ() + dir.z);
            }
        }
        leaveTicks++;
        if (getNavigation().isDone()) getNavigation().moveTo(waterTarget.getX() + 0.5, waterTarget.getY(), waterTarget.getZ() + 0.5, 1.0);
        if (blockPosition().distSqr(waterTarget) < 9 || leaveTicks > 1200) vanish(true);
    }

    public void vanish(boolean big) {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), big ? 80 : 20, 0.4, 1.0, 0.4, 0.02);
            if (big) sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 1, getZ(), 40, 0.4, 1.0, 0.4, 0.03);
        }
        discard();
    }

    // ---------- spawning ----------
    public static CreatorEntity spawnBehind(ServerLevel lv, ServerPlayer p, int state) {
        Vec3 look = p.getLookAngle();
        Vec3 back = new Vec3(-look.x, 0, -look.z);
        back = back.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : back.normalize();
        Vec3 pos = null;
        for (int dist : new int[]{4, 3, 5, 6, 2}) {
            pos = findStand(lv, p.getX() + back.x * dist, p.getY(), p.getZ() + back.z * dist);
            if (pos != null) break;
        }
        if (pos == null) pos = p.position().add(back.scale(3));
        CreatorEntity c = TheCreatorMod.CREATOR.get().create(lv);
        float yaw = (float) (Mth.atan2(p.getZ() - pos.z, p.getX() - pos.x) * 57.29578F) - 90F;
        c.moveTo(pos.x, pos.y, pos.z, yaw, 0F);
        c.yHeadRot = yaw;
        c.yBodyRot = yaw;
        lv.addFreshEntity(c);
        if (state == SPEAK_BREAK) c.startBreakSpeech();
        else if (state == CHASE) c.startChase(p);
        return c;
    }

    private static Vec3 findStand(ServerLevel lv, double x, double y, double z) {
        BlockPos base = BlockPos.containing(x, y, z);
        for (int dy = 3; dy >= -4; dy--) {
            BlockPos b = base.above(dy);
            if (lv.getBlockState(b).getCollisionShape(lv, b).isEmpty()
                    && lv.getBlockState(b.above()).getCollisionShape(lv, b.above()).isEmpty()
                    && !lv.getBlockState(b.below()).getCollisionShape(lv, b.below()).isEmpty())
                return new Vec3(b.getX() + 0.5, b.getY(), b.getZ() + 0.5);
        }
        return null;
    }

    @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); t.putInt("CState", getState()); }
    @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); setState(t.getInt("CState")); }
}
