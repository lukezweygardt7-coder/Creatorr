# The Creator (Forge 1.20.1) - first full build

## Build
1. Download the Forge **1.20.1-47.3.0 MDK** (files.minecraftforge.net) and unzip it.
2. Copy this project's `src/` folder, `build.gradle` and `gradle.properties` over the MDK's (keep the MDK's `gradlew` files).
3. Run `./gradlew build` (Windows: `gradlew build`). The jar lands in `build/libs/`. Needs Java 17.
4. To try it without installing: `./gradlew runClient`.

No GeckoLib needed: the model is a 73k-triangle Blockbench *mesh*, which GeckoLib cannot draw, so the mod has its own mesh renderer.

## Test commands (op)
`/creator spawn`, `/creator chase`, `/creator speech`, `/creator dream`, `/creator reset`

## Things most likely to need a tweak (all one-line constants)
- `client/CreatorMesh.java`: `ROT_*` / `POS_*` signs if the animation looks mirrored, `HEAD_YAW_SIGN` / `HEAD_PITCH_SIGN` if the head turns the wrong way, `HEIGHT_BLOCKS` (2.0 = player-like; the raw model is 5 blocks tall).
- `ItemTiers.java`: item tiers and caps.
- `RuleBookModifier.PAGES`: pages 4 and 5 are TODO.
- `DreamRoom.java`: the room layout.
- `ServerEvents.java`: `DREAM_DAY`, `COUNTDOWN_DAYS`.

## Re-converting a changed model
`python3 tools/convert_bbmodel.py tools/source/Creator.bbmodel src/main/resources` (needs Pillow).

## Entity size and durability
The mesh is 80 Blockbench units tall, so the entity is registered at 5 blocks high with a matching eye height and culling/collision bounds. The Creator ignores all normal damage and the ordinary `KILLED` removal path; the mod can still remove him with its scripted vanish behavior.

## Creator model source

The original editable Blockbench free-mesh model is included at `tools/source/Creator.bbmodel`.
To regenerate the runtime mesh, animations, and texture PNGs after editing it, run:

```bash
python3 tools/convert_bbmodel.py tools/source/Creator.bbmodel src/main/resources
```

This model is a dense free-mesh model (not a cube-only GeckoLib model), so the project uses its custom triangle-mesh renderer. GeckoLib is not required for this format.
