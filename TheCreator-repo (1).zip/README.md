# The Creator (Forge 1.20.1) - first full build

## Build
1. Download the Forge **1.20.1-47.3.0 MDK** (files.minecraftforge.net) and unzip it.
2. Copy this project's `src/` folder, `build.gradle` and `gradle.properties` over the MDK's (keep the MDK's `gradlew` files).
3. Run `./gradlew build` (Windows: `gradlew build`). The jar lands in `build/libs/`. Needs Java 17.
4. To try it without installing: `./gradlew runClient`.

No GeckoLib needed: the model is a 73k-triangle Blockbench *mesh*, which GeckoLib cannot draw, so the mod has its own mesh renderer.

## Test commands (op)
`/creator spawn`, `/creator chase`, `/creator speech`, `/creator dream`, `/creator reset`

## Things most likely to need a tweak (all one-line constants)
- `client/CreatorMesh.java`: `ROT_*` / `POS_*` signs if the animation looks mirrored, `HEAD_YAW_SIGN` / `HEAD_PITCH_SIGN` if the head turns the wrong way, `HEIGHT_BLOCKS` (2.0 = player-like; the raw model is 5 blocks tall).
- `ItemTiers.java`: item tiers and caps.
- `RuleBookModifier.PAGES`: pages 4 and 5 are TODO.
- `DreamRoom.java`: the room layout.
- `ServerEvents.java`: `DREAM_DAY`, `COUNTDOWN_DAYS`.

## Re-converting a changed model
`python3 tools/convert_bbmodel.py Creator.bbmodel src/main/resources` (needs Pillow).
