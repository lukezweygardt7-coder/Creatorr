#!/usr/bin/env python3
"""Converts a Blockbench 'free' mesh model (.bbmodel) into the files the mod loads:
   models/creator.mesh (gzip binary), animations/creator.json, textures/entity/creator/*.png
Usage: python3 convert_bbmodel.py Creator.bbmodel <resources_dir>"""
import json, sys, struct, gzip, base64, io, os, math
from PIL import Image

src, out = sys.argv[1], sys.argv[2]
d = json.load(open(src))
els = {e['uuid']: e for e in d['elements']}
groups = {g['uuid']: g for g in d['groups']}
RES = float(d['resolution']['width'])

# ---- textures
tex_dir = os.path.join(out, 'assets/thecreator/textures/entity/creator'); os.makedirs(tex_dir, exist_ok=True)
tex_names = []
for i, t in enumerate(d['textures']):
    name = os.path.splitext(t['name'])[0].lower()
    img = Image.open(io.BytesIO(base64.b64decode(t['source'].split(',', 1)[1])))
    img.convert('RGBA').save(os.path.join(tex_dir, name + '.png'))
    tex_names.append(name)
print('textures', tex_names)

# ---- bones
bones, bone_idx = [], {}
mesh_of_bone = {}
def walk(node, parent):
    if isinstance(node, str):
        mesh_of_bone.setdefault(parent, []).append(els[node]); return
    g = groups[node['uuid']]
    idx = len(bones); bone_idx[g['name']] = idx
    bones.append({'name': g['name'], 'parent': parent, 'pivot': g['origin'], 'rot': g.get('rotation', [0,0,0])})
    for c in node.get('children', []): walk(c, idx)
for n in d['outliner']: walk(n, -1)
assert all(abs(v) < 1e-6 for b in bones for v in b['rot']), 'non-zero rest rotation, not supported'

# ---- meshes
mn = [1e9]*3; mx = [-1e9]*3
tex_use = {}
buf = io.BytesIO()
buf.write(b'CMSH'); buf.write(struct.pack('>i', len(bones)))
total_tris = 0
for bi, b in enumerate(bones):
    nm = b['name'].encode()
    buf.write(struct.pack('>H', len(nm))); buf.write(nm)
    buf.write(struct.pack('>i3f', b['parent'], *b['pivot']))
    per_tex = {}
    for e in mesh_of_bone.get(bi, []):
        assert all(abs(x)<1e-6 for x in e.get('rotation',[0,0,0])), 'mesh rotation unsupported'
        o = e.get('origin',[0,0,0])
        V = {k:[v[0]+o[0],v[1]+o[1],v[2]+o[2]] for k,v in e['vertices'].items()}
        cx = [sum(v[k] for v in V.values())/len(V) for k in range(3)]
        for f in e['faces'].values():
            vs = f['vertices']
            if len(vs) < 3: continue
            ti = int(f.get('texture', 0) or 0)
            tex_use.setdefault(e['name'], set()).add(tex_names[ti])
            for k in range(1, len(vs)-1):
                tri = [vs[0], vs[k], vs[k+1]]
                P = [V[v] for v in tri]
                a = [P[1][j]-P[0][j] for j in range(3)]; c = [P[2][j]-P[0][j] for j in range(3)]
                n = [a[1]*c[2]-a[2]*c[1], a[2]*c[0]-a[0]*c[2], a[0]*c[1]-a[1]*c[0]]
                l = math.sqrt(sum(x*x for x in n)) or 1.0; n = [x/l for x in n]
                mid = [sum(p[j] for p in P)/3 - cx[j] for j in range(3)]
                if sum(n[j]*mid[j] for j in range(3)) < 0: n = [-x for x in n]   # point outward
                for v, p in zip(tri, P):
                    uv = f['uv'].get(v, [0, 0])
                    for j in range(3): mn[j] = min(mn[j], p[j]); mx[j] = max(mx[j], p[j])
                    per_tex.setdefault(ti, []).extend([p[0], p[1], p[2], uv[0]/RES, uv[1]/RES, n[0], n[1], n[2]])
    buf.write(struct.pack('>i', len(per_tex)))
    for ti, arr in per_tex.items():
        cnt = len(arr)//8
        buf.write(struct.pack('>ii', ti, cnt // 3)); total_tris += cnt // 3
        buf.write(struct.pack('>%df' % len(arr), *arr))
mdl = os.path.join(out, 'assets/thecreator/models'); os.makedirs(mdl, exist_ok=True)
with gzip.open(os.path.join(mdl, 'creator.mesh'), 'wb', 6) as f: f.write(buf.getvalue())
print('bones', len(bones), 'triangles', total_tris, 'bounds min', [round(x,1) for x in mn], 'max', [round(x,1) for x in mx])
print('texture use by mesh (non-skin only):', {k: sorted(v) for k, v in tex_use.items() if v != {'skin'}})

# ---- animations
def num(s):
    try: return float(s)
    except Exception: return 0.0
anims = {}; bad = 0
for a in d['animations']:
    A = {'length': a.get('length', 0), 'loop': a.get('loop') == 'loop', 'bones': {}}
    for an in a['animators'].values():
        ch = {}
        for kf in an.get('keyframes', []):
            dp = kf['data_points'][0]
            if any(not str(dp.get(k, '0')).replace('.', '', 1).lstrip('-').isdigit() for k in 'xyz'): bad += 1
            ch.setdefault(kf['channel'], []).append([kf['time'], num(dp['x']), num(dp['y']), num(dp['z']),
                                                      {'linear':0,'catmullrom':1,'step':2}.get(kf.get('interpolation','linear'), 0)])
        for v in ch.values(): v.sort(key=lambda k: k[0])
        if ch: A['bones'][an['name']] = ch
    anims[a['name']] = A
print('non-numeric keyframe values:', bad)
ad = os.path.join(out, 'assets/thecreator/animations'); os.makedirs(ad, exist_ok=True)
json.dump(anims, open(os.path.join(ad, 'creator.json'), 'w'), separators=(',', ':'))
print({k: (v['length'], v['loop'], len(v['bones'])) for k, v in anims.items()})
