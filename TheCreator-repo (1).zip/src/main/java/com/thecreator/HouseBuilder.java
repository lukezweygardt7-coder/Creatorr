package com.thecreator;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/** Places house.nbt one layer at a time, only while nobody is looking at the site. */
public final class HouseBuilder {
    private record Entry(BlockPos pos, BlockState state, CompoundTag nbt) {}

    private static List<List<Entry>> layers;
    private static int sx, sy, sz, groundY;
    private static final int LAYER_DELAY_TICKS = 100;

    private static synchronized boolean load(ServerLevel lv) {
        if (layers != null) return true;
        try (InputStream in = lv.getServer().getResourceManager()
                .getResource(new ResourceLocation(TheCreatorMod.ID, "structures/house.nbt")).get().open()) {
            CompoundTag root = NbtIo.readCompressed(in);
            ListTag size = root.getList("size", Tag.TAG_INT);
            sx = size.getInt(0); sy = size.getInt(1); sz = size.getInt(2);
            ListTag palette = root.getList("palette", Tag.TAG_COMPOUND);
            List<BlockState> states = new ArrayList<>();
            for (int i = 0; i < palette.size(); i++)
                states.add(NbtUtils.readBlockState(lv.holderLookup(Registries.BLOCK), palette.getCompound(i)));
            TreeMap<Integer, List<Entry>> byY = new TreeMap<>();
            java.util.Map<Integer, Integer> grass = new java.util.HashMap<>();
            ListTag blocks = root.getList("blocks", Tag.TAG_COMPOUND);
            for (int i = 0; i < blocks.size(); i++) {
                CompoundTag b = blocks.getCompound(i);
                ListTag p = b.getList("pos", Tag.TAG_INT);
                BlockState st = states.get(b.getInt("state"));
                if (st.is(net.minecraft.world.level.block.Blocks.GRASS_BLOCK)) grass.merge(p.getInt(1), 1, Integer::sum);
                byY.computeIfAbsent(p.getInt(1), k -> new ArrayList<>())
                        .add(new Entry(new BlockPos(p.getInt(0), p.getInt(1), p.getInt(2)), st, b.contains("nbt") ? b.getCompound("nbt") : null));
            }
            groundY = grass.entrySet().stream().max(java.util.Map.Entry.comparingByValue()).map(java.util.Map.Entry::getKey).orElse(0);
            layers = new ArrayList<>(byY.values());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean insideHouse(CreatorData d, BlockPos p) {
        if (!d.houseBuilt || layers == null) return false;
        BlockPos o = d.houseOrigin;
        return p.getX() >= o.getX() && p.getX() < o.getX() + sx && p.getY() >= o.getY() && p.getY() < o.getY() + sy
                && p.getZ() >= o.getZ() && p.getZ() < o.getZ() + sz;
    }

    /** Above-ground block inside the house footprint (what counts toward the 6 broken blocks). */
    public static boolean isHouseBlock(CreatorData d, BlockPos p) {
        return insideHouse(d, p) && p.getY() > d.houseOrigin.getY() + groundY;
    }

    public static boolean start(ServerLevel lv, ServerPlayer p, CreatorData d) {
        if (!load(lv)) return false;
        Vec3 look = p.getLookAngle();
        Vec3 dir = new Vec3(look.x, 0, look.z);
        dir = dir.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : dir.normalize();
        double dist = 10 + Math.max(sx, sz) / 2.0;
        int cx = (int) Math.floor(p.getX() + dir.x * dist), cz = (int) Math.floor(p.getZ() + dir.z * dist);
        int surface = lv.getHeight(Heightmap.Types.WORLD_SURFACE, cx, cz);
        d.houseOrigin = new BlockPos(cx - sx / 2, surface - groundY - 1, cz - sz / 2);
        d.houseBuilt = true;
        d.builtLayers = 0;
        d.broken.clear();
        d.setDirty();
        return true;
    }

    private static boolean watched(ServerLevel lv, CreatorData d) {
        Vec3 centre = Vec3.atCenterOf(d.houseOrigin.offset(sx / 2, sy / 2, sz / 2));
        for (ServerPlayer p : lv.players()) {
            Vec3 to = centre.subtract(p.getEyePosition());
            double dist = to.length();
            if (dist < 12) return true;                    // standing at the site counts as looking
            if (dist < 200 && p.getViewVector(1F).dot(to.normalize()) > 0.3) return true;
        }
        return false;
    }

    public static void tick(ServerLevel lv, CreatorData d, long gameTime) {
        if (!d.houseBuilt || gameTime % LAYER_DELAY_TICKS != 0 || !load(lv) || d.builtLayers >= layers.size()) return;
        if (watched(lv, d)) return;
        BlockPos o = d.houseOrigin;
        if (!lv.hasChunksAt(o, o.offset(sx, 0, sz))) return;
        for (Entry e : layers.get(d.builtLayers)) {
            BlockPos at = o.offset(e.pos());
            lv.setBlock(at, e.state(), 2);
            if (e.nbt() != null) {
                BlockEntity be = lv.getBlockEntity(at);
                if (be != null) {
                    CompoundTag t = e.nbt().copy();
                    t.putInt("x", at.getX()); t.putInt("y", at.getY()); t.putInt("z", at.getZ());
                    be.load(t);
                    be.setChanged();
                }
            }
        }
        d.builtLayers++;
        d.setDirty();
    }

    private HouseBuilder() {}
}
