package com.thecreator;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;

import java.util.Set;

/** How much the Creator is willing to hand over. Edit the sets and numbers to taste. */
public final class ItemTiers {
    public enum Tier {
        BASIC(0, 0), MID(32, 64), VALUABLE(30, 64), RARE(2, 4), NEVER(0, 0);
        public final int base, max;
        Tier(int base, int max) { this.base = base; this.max = max; }
    }

    private static final Set<String> NEVER = Set.of("command_block", "chain_command_block", "repeating_command_block",
            "command_block_minecart", "structure_block", "structure_void", "jigsaw", "barrier", "light", "bedrock",
            "debug_stick", "knowledge_book", "spawner", "dragon_egg", "end_portal_frame", "reinforced_deepslate",
            "budding_amethyst", "petrified_oak_slab", "farmland", "dirt_path", "air");
    private static final Set<String> RARE = Set.of("netherite_ingot", "netherite_scrap", "netherite_block", "ancient_debris",
            "nether_star", "totem_of_undying", "elytra", "enchanted_golden_apple", "beacon", "heart_of_the_sea", "trident",
            "shulker_shell", "conduit", "dragon_head", "wither_skeleton_skull");
    private static final Set<String> VALUABLE = Set.of("diamond", "emerald", "ender_pearl", "blaze_rod", "diamond_block",
            "emerald_block", "ender_eye", "ghast_tear", "golden_apple", "experience_bottle", "end_crystal");
    private static final Set<String> MID = Set.of("iron_ingot", "gold_ingot", "copper_ingot", "redstone", "lapis_lazuli",
            "quartz", "amethyst_shard", "glowstone_dust", "iron_block", "gold_block", "raw_iron", "raw_gold", "raw_copper");

    public static Tier of(Item item) {
        String id = BuiltInRegistries.ITEM.getKey(item).getPath();
        if (NEVER.contains(id) || item instanceof SpawnEggItem) return Tier.NEVER;
        if (RARE.contains(id) || id.startsWith("netherite_")) return Tier.RARE;
        if (VALUABLE.contains(id) || id.startsWith("diamond_") || id.startsWith("emerald_")) return Tier.VALUABLE;
        if (MID.contains(id) || id.startsWith("iron_") || id.startsWith("golden_") || id.startsWith("chainmail_")) return Tier.MID;
        Rarity r = item.getDefaultInstance().getRarity();
        if (r == Rarity.EPIC) return Tier.RARE;
        if (r == Rarity.RARE) return Tier.VALUABLE;
        if (r == Rarity.UNCOMMON) return Tier.MID;
        return Tier.BASIC;
    }

    /** Largest amount he will agree to at the current (hidden) satisfaction. */
    public static int cap(Item item, Tier t, float satisfaction) {
        if (t == Tier.NEVER) return 0;
        int stack = Math.max(1, item.getMaxStackSize());
        if (t == Tier.BASIC) return stack;
        float f = Math.max(0F, Math.min(1F, (satisfaction - 0.7F) / 0.3F));   // caps only rise near max satisfaction
        int c = Math.round(t.base + (t.max - t.base) * f);
        return Math.max(1, Math.min(c, stack));
    }

    private ItemTiers() {}
}
