package com.thecreator;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.LongArrayTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashSet;
import java.util.Set;

/** All per-world state lives here (overworld save data), so dimensions can never reset it. */
public class CreatorData extends SavedData {
    public long startDay = -1;                 // set when the README book is first read
    public float satisfaction = 0.5F;        // hidden, never displayed
    public boolean houseBuilt, speechDone, dreamDone, dreamRoomBuilt, bookRead, chestPlaced;
    public BlockPos houseOrigin = BlockPos.ZERO;
    public int builtLayers;
    public final Set<Long> broken = new HashSet<>();

    public static CreatorData get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(CreatorData::load, CreatorData::new, "thecreator");
    }

    public static CreatorData load(CompoundTag t) {
        CreatorData d = new CreatorData();
        d.startDay = t.getLong("startDay");
        d.satisfaction = t.contains("sat") ? t.getFloat("sat") : 0.5F;
        d.houseBuilt = t.getBoolean("houseBuilt");
        d.speechDone = t.getBoolean("speechDone");
        d.dreamDone = t.getBoolean("dreamDone");
        d.dreamRoomBuilt = t.getBoolean("dreamRoomBuilt");
        d.bookRead = t.getBoolean("bookRead");
        d.chestPlaced = t.getBoolean("chestPlaced");
        if (t.contains("origin")) d.houseOrigin = NbtUtils.readBlockPos(t.getCompound("origin"));
        d.builtLayers = t.getInt("layers");
        for (long l : t.getLongArray("broken")) d.broken.add(l);
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putLong("startDay", startDay);
        t.putFloat("sat", satisfaction);
        t.putBoolean("houseBuilt", houseBuilt);
        t.putBoolean("speechDone", speechDone);
        t.putBoolean("dreamDone", dreamDone);
        t.putBoolean("dreamRoomBuilt", dreamRoomBuilt);
        t.putBoolean("bookRead", bookRead);
        t.putBoolean("chestPlaced", chestPlaced);
        t.put("origin", NbtUtils.writeBlockPos(houseOrigin));
        t.putInt("layers", builtLayers);
        t.put("broken", new LongArrayTag(broken.stream().mapToLong(Long::longValue).toArray()));
        return t;
    }

    public void addSatisfaction(float d) {
        satisfaction = Math.max(0F, Math.min(1F, satisfaction + d));
        setDirty();
    }
}
