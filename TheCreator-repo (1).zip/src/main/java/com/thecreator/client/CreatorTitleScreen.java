package com.thecreator.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/** Custom home screen with a short intro (black -> title fade-in). Placeholder art; send your own assets to replace it. */
public class CreatorTitleScreen extends Screen {
    private static boolean introDone = false;
    private long start = -1;
    private Button[] buttons;

    public CreatorTitleScreen() { super(Component.literal("The Creator")); }

    @Override
    protected void init() {
        int cx = width / 2, y = height / 2 + 10;
        buttons = new Button[]{
            addRenderableWidget(Button.builder(Component.literal("Singleplayer"), b -> minecraft.setScreen(new SelectWorldScreen(this))).bounds(cx - 100, y, 200, 20).build()),
            addRenderableWidget(Button.builder(Component.literal("Multiplayer"), b -> minecraft.setScreen(new JoinMultiplayerScreen(this))).bounds(cx - 100, y + 26, 200, 20).build()),
            addRenderableWidget(Button.builder(Component.literal("Options"), b -> minecraft.setScreen(new OptionsScreen(this, minecraft.options))).bounds(cx - 100, y + 52, 98, 20).build()),
            addRenderableWidget(Button.builder(Component.literal("Quit"), b -> minecraft.stop()).bounds(cx + 2, y + 52, 98, 20).build())};
        for (Button b : buttons) b.visible = introDone;
    }

    @Override public boolean shouldCloseOnEsc() { return false; }

    @Override
    public boolean mouseClicked(double x, double y, int btn) {
        if (!introDone) { finishIntro(); return true; }
        return super.mouseClicked(x, y, btn);
    }

    private void finishIntro() {
        introDone = true;
        if (buttons != null) for (Button b : buttons) b.visible = true;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        if (start < 0) start = System.currentTimeMillis();
        float s = (System.currentTimeMillis() - start) / 1000F;
        g.fillGradient(0, 0, width, height, 0xFF050508, 0xFF1A0508);
        if (!introDone) {                                                   // intro: 0-1s black, 1-3s title fades in, 3-4s holds
            float a = Mth.clamp((s - 1F) / 2F, 0F, 1F);
            int c = ((int) (a * 255) << 24) | 0xC01818;
            g.pose().pushPose();
            g.pose().translate(width / 2F, height / 2F - 10, 0);
            g.pose().scale(4F, 4F, 1F);
            g.drawCenteredString(font, "THE CREATOR", 0, -4, c);
            g.pose().popPose();
            if (s > 4F) finishIntro();
            return;
        }
        g.pose().pushPose();
        g.pose().translate(width / 2F, height / 2F - 50, 0);
        g.pose().scale(4F, 4F, 1F);
        g.drawCenteredString(font, "THE CREATOR", 0, -4, 0xFFC01818);
        g.pose().popPose();
        super.render(g, mx, my, pt);
    }
}
