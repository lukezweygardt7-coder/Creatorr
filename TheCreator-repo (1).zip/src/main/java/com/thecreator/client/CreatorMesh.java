package com.thecreator.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.thecreator.TheCreatorMod;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.io.DataInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * Loads the converted Blockbench mesh (models/creator.mesh) and plays the converted animations on its bones.
 * Every Blockbench convention that could not be verified offline is a constant below, so a wrong-looking pose
 * can be fixed by flipping one sign.
 */
public final class CreatorMesh {
    /** Blockbench animation sign conventions (Blockbench negates X/Y rotation and X position). */
    static final float ROT_X = -1, ROT_Y = -1, ROT_Z = 1, POS_X = -1, POS_Y = 1, POS_Z = 1;
    /** Head tracking directions in the model's own space. */
    static final float HEAD_YAW_SIGN = -1, HEAD_PITCH_SIGN = 1;
    /** Added to the body yaw. The model's front is +Z, so 0. Use 180 if he ever faces backwards again. */
    public static final float FACING_OFFSET = 0F;
    /** The model is 80 Blockbench units tall; this is how tall he is in blocks. 5.0 = native size (1 unit = 1/16 block), 2.0 = player-like. */
    public static final float HEIGHT_BLOCKS = 5.0F;
    public static final float SCALE = HEIGHT_BLOCKS / 80F;

    static final class Bone {
        String name; int parent; float px, py, pz;
        int[] tex; int[] tris; float[][] data;      // per texture group: x y z u v nx ny nz
        float headYawWeight, headPitchWeight;
        Matrix4f world = new Matrix4f();
    }
    static final class Anim {
        float length; boolean loop;
        Map<String, Map<String, float[][]>> bones = new HashMap<>();    // bone -> channel -> keyframes [t,x,y,z,interp]
    }

    static Bone[] bones;
    static final Map<String, Anim> anims = new HashMap<>();
    static boolean loaded, failed;

    static synchronized boolean ensureLoaded(ResourceManager rm) {
        if (loaded) return true;
        if (failed) return false;
        try {
            try (DataInputStream in = new DataInputStream(new GZIPInputStream(rm.getResource(
                    new ResourceLocation(TheCreatorMod.ID, "models/creator.mesh")).get().open(), 1 << 16))) {
                byte[] magic = new byte[4]; in.readFully(magic);
                int n = in.readInt();
                bones = new Bone[n];
                for (int i = 0; i < n; i++) {
                    Bone b = new Bone();
                    byte[] nm = new byte[in.readUnsignedShort()]; in.readFully(nm);
                    b.name = new String(nm, java.nio.charset.StandardCharsets.UTF_8);
                    b.parent = in.readInt(); b.px = in.readFloat(); b.py = in.readFloat(); b.pz = in.readFloat();
                    int g = in.readInt();
                    b.tex = new int[g]; b.tris = new int[g]; b.data = new float[g][];
                    for (int k = 0; k < g; k++) {
                        b.tex[k] = in.readInt(); b.tris[k] = in.readInt();
                        float[] arr = new float[b.tris[k] * 3 * 8];
                        for (int j = 0; j < arr.length; j++) arr[j] = in.readFloat();
                        b.data[k] = arr;
                    }
                    switch (b.name) {      // how much of the head turn each bone takes
                        case "neck", "neck_bridge" -> { b.headYawWeight = 0.35F; b.headPitchWeight = 0.35F; }
                        case "head", "head_bridge" -> { b.headYawWeight = 0.65F; b.headPitchWeight = 0.65F; }
                        default -> {}
                    }
                    bones[i] = b;
                }
            }
            try (InputStream is = rm.getResource(new ResourceLocation(TheCreatorMod.ID, "animations/creator.json")).get().open()) {
                JsonObject root = JsonParser.parseReader(new InputStreamReader(is)).getAsJsonObject();
                for (Map.Entry<String, JsonElement> ae : root.entrySet()) {
                    JsonObject o = ae.getValue().getAsJsonObject();
                    Anim a = new Anim();
                    a.length = o.get("length").getAsFloat(); a.loop = o.get("loop").getAsBoolean();
                    for (Map.Entry<String, JsonElement> be : o.getAsJsonObject("bones").entrySet()) {
                        Map<String, float[][]> chans = new HashMap<>();
                        for (Map.Entry<String, JsonElement> ce : be.getValue().getAsJsonObject().entrySet()) {
                            JsonArray kfs = ce.getValue().getAsJsonArray();
                            float[][] arr = new float[kfs.size()][5];
                            for (int i = 0; i < arr.length; i++) for (int j = 0; j < 5; j++) arr[i][j] = kfs.get(i).getAsJsonArray().get(j).getAsFloat();
                            chans.put(ce.getKey(), arr);
                        }
                        a.bones.put(be.getKey(), chans);
                    }
                    anims.put(ae.getKey(), a);
                }
            }
            loaded = true;
        } catch (Exception ex) {
            failed = true;
            ex.printStackTrace();
        }
        return loaded;
    }

    private static float[] sample(float[][] k, float t, float[] out) {
        if (k.length == 1 || t <= k[0][0]) { out[0] = k[0][1]; out[1] = k[0][2]; out[2] = k[0][3]; return out; }
        int last = k.length - 1;
        if (t >= k[last][0]) { out[0] = k[last][1]; out[1] = k[last][2]; out[2] = k[last][3]; return out; }
        int i = 0;
        while (i < last - 1 && k[i + 1][0] <= t) i++;
        float[] a = k[i], b = k[i + 1];
        float f = (t - a[0]) / Math.max(1e-6F, b[0] - a[0]);
        if (a[4] == 2) f = 0;                                    // step
        for (int j = 0; j < 3; j++) {
            if (a[4] == 1 && b[4] != 2) {                        // catmull-rom
                float p0 = (i > 0 ? k[i - 1] : a)[j + 1], p1 = a[j + 1], p2 = b[j + 1], p3 = (i + 2 <= last ? k[i + 2] : b)[j + 1];
                out[j] = 0.5F * ((2 * p1) + (-p0 + p2) * f + (2 * p0 - 5 * p1 + 4 * p2 - p3) * f * f + (-p0 + 3 * p1 - 3 * p2 + p3) * f * f * f);
            } else out[j] = a[j + 1] + (b[j + 1] - a[j + 1]) * f;
        }
        return out;
    }

    /** Computes every bone's world matrix for this animation, time (seconds) and head turn (degrees). */
    static void pose(String animName, float time, float headYaw, float headPitch) {
        Anim a = anims.get(animName);
        float t = 0;
        if (a != null && a.length > 0) t = a.loop ? time % a.length : Math.min(time, a.length);
        float[] v = new float[3];
        Matrix4f local = new Matrix4f();
        for (Bone b : bones) {
            Map<String, float[][]> ch = a == null ? null : a.bones.get(b.name);
            float rx = 0, ry = 0, rz = 0, tx = 0, ty = 0, tz = 0, sx = 1, sy = 1, sz = 1;
            if (ch != null) {
                if (ch.containsKey("rotation")) { sample(ch.get("rotation"), t, v); rx = v[0] * ROT_X; ry = v[1] * ROT_Y; rz = v[2] * ROT_Z; }
                if (ch.containsKey("position")) { sample(ch.get("position"), t, v); tx = v[0] * POS_X; ty = v[1] * POS_Y; tz = v[2] * POS_Z; }
                if (ch.containsKey("scale")) { sample(ch.get("scale"), t, v); sx = v[0]; sy = v[1]; sz = v[2]; }
            }
            local.identity().translate(b.px, b.py, b.pz).translate(tx, ty, tz);
            if (b.headYawWeight > 0) local.rotateY((float) Math.toRadians(headYaw * b.headYawWeight * HEAD_YAW_SIGN))
                                             .rotateX((float) Math.toRadians(headPitch * b.headPitchWeight * HEAD_PITCH_SIGN));
            local.rotateZ((float) Math.toRadians(rz)).rotateY((float) Math.toRadians(ry)).rotateX((float) Math.toRadians(rx))
                 .scale(sx, sy, sz).translate(-b.px, -b.py, -b.pz);
            if (b.parent >= 0) bones[b.parent].world.mul(local, b.world); else b.world.set(local);
        }
    }

    /** Emits every triangle of one texture slot. The PoseStack must already hold entity position/yaw/scale. */
    static void emit(PoseStack ps, VertexConsumer vc, int texSlot, int light, float alpha) {
        Matrix3f n3 = new Matrix3f();
        int a = (int) (alpha * 255);
        for (Bone b : bones) {
            for (int g = 0; g < b.tex.length; g++) {
                if (b.tex[g] != texSlot) continue;
                ps.pushPose();
                ps.last().pose().mul(b.world);
                b.world.normal(n3);
                ps.last().normal().mul(n3);
                PoseStack.Pose pose = ps.last();
                float[] d = b.data[g];
                for (int i = 0; i < d.length; i += 8)
                    vc.vertex(pose.pose(), d[i], d[i + 1], d[i + 2]).color(255, 255, 255, a).uv(d[i + 3], d[i + 4])
                      .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(pose.normal(), d[i + 5], d[i + 6], d[i + 7]).endVertex();
                ps.popPose();
            }
        }
    }

    private CreatorMesh() {}
}
