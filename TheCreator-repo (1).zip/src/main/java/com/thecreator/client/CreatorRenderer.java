package com.thecreator.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.thecreator.CreatorEntity;
import com.thecreator.TheCreatorMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class CreatorRenderer extends EntityRenderer<CreatorEntity> {
    private static final ResourceLocation[] TEX = new ResourceLocation[4];
    static {
        String[] n = {"skin", "eye0", "eye1", "mouth"};
        for (int i = 0; i < 4; i++) TEX[i] = new ResourceLocation(TheCreatorMod.ID, "textures/entity/creator/" + n[i] + ".png");
    }

    public CreatorRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.5F;
    }

    @Override
    public ResourceLocation getTextureLocation(CreatorEntity e) { return TEX[0]; }

    @Override
    public void render(CreatorEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        if (!CreatorMesh.ensureLoaded(Minecraft.getInstance().getResourceManager())) return;

        int glitch = e.getGlitch();
        if (glitch > 0 && ((e.tickCount + (int) (pt * 3)) % 3 == 0)) return;     // flicker while the "switch" plays

        float body = Mth.rotLerp(pt, e.yBodyRotO, e.yBodyRot);
        float head = Mth.rotLerp(pt, e.yHeadRotO, e.yHeadRot);
        float netYaw = Mth.clamp(Mth.wrapDegrees(head - body), -75F, 75F);
        float pitch = Mth.clamp(Mth.lerp(pt, e.xRotO, e.getXRot()), -40F, 40F);

        String anim = switch (e.getState()) {
            case CreatorEntity.SPEAK_BREAK -> "idle mad";
            case CreatorEntity.LEAVE -> "running";
            case CreatorEntity.CHASE -> "sprinting";
            case CreatorEntity.DREAM -> "dream";
            default -> "idle";
        };
        float time = (e.tickCount + pt) / 20F;
        CreatorMesh.pose(anim, time, netYaw, pitch);

        ps.pushPose();
        if (glitch > 0) ps.translate((Math.sin(time * 90) * 0.09) * glitch / 14.0, 0, (Math.cos(time * 70) * 0.05) * glitch / 14.0);
        ps.mulPose(Axis.YP.rotationDegrees(CreatorMesh.FACING_OFFSET - body));
        ps.scale(CreatorMesh.SCALE, CreatorMesh.SCALE, CreatorMesh.SCALE);

        CreatorMesh.emit(ps, buf.getBuffer(RenderType.entityCutoutNoCull(TEX[0])), 0, light, 1F);
        for (int slot = 1; slot < 4; slot++)          // eyes and mouth: full-bright translucent layers
            CreatorMesh.emit(ps, buf.getBuffer(RenderType.entityTranslucent(TEX[slot])), slot, LightTexture.FULL_BRIGHT, 1F);
        ps.popPose();
    }
}
