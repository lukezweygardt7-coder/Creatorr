package com.thecreator.client;

import com.thecreator.ClientState;
import com.thecreator.TheCreatorMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.client.event.ViewportEvent;
import com.thecreator.CreatorEntity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class ClientEvents {
    private static final ResourceLocation DREAM_DIM = new ResourceLocation(TheCreatorMod.ID, "dream");
    private static final ResourceLocation DREAM_SHADER = new ResourceLocation(TheCreatorMod.ID, "shaders/post/dream.json");
    private static final ResourceLocation CHASE_SHADER = new ResourceLocation(TheCreatorMod.ID, "shaders/post/chase.json");
    private static ResourceLocation activeShader;

    @Mod.EventBusSubscriber(modid = TheCreatorMod.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(TheCreatorMod.CREATOR.get(), CreatorRenderer::new);
        }

        /** Countdown: black box + "starts in N days" at the action-bar position, matching the screenshot. */
        @SubscribeEvent
        public static void overlays(RegisterGuiOverlaysEvent e) {
            e.registerAboveAll("countdown", (gui, g, pt, w, h) -> {
                int days = ClientState.countdown;
                Minecraft mc = Minecraft.getInstance();
                if (days <= 0 || mc.options.hideGui) return;
                Font f = mc.font;
                String text = "starts in " + days + (days == 1 ? " day" : " days");
                int boxW = 46, boxH = 15, gap = 4;                    // measured from the screenshot at its GUI scale
                int x = (w - (boxW + gap + f.width(text))) / 2;
                int boxY = h - 66;
                g.fill(x, boxY, x + boxW, boxY + boxH, 0xFF000000);
                g.drawString(f, text, x + boxW + gap, boxY + (boxH - 8) / 2 + 1, 0xFFFFFF, true);
            });
        }
    }

    @Mod.EventBusSubscriber(modid = TheCreatorMod.ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void title(ScreenEvent.Opening e) {
            if (e.getNewScreen() instanceof TitleScreen) e.setNewScreen(new CreatorTitleScreen());
        }

        /** Dream shader in the dream dimension, gloomy chase shader only while he is chasing you. */
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            ResourceLocation want = null;
            if (mc.level != null) {
                if (mc.level.dimension().location().equals(DREAM_DIM)) want = DREAM_SHADER;
                else if (ClientState.chasing) want = CHASE_SHADER;
            }
            if (!java.util.Objects.equals(want, activeShader)) {
                if (want == null) mc.gameRenderer.shutdownEffect(); else mc.gameRenderer.loadEffect(want);
                activeShader = want;
            }
        }

        /** Small camera shake during chases, a little stronger the closer he is. */
        @SubscribeEvent
        public static void shake(ViewportEvent.ComputeCameraAngles e) {
            Minecraft mc = Minecraft.getInstance();
            if (!ClientState.chasing || mc.player == null || mc.level == null || mc.isPaused()) return;
            double dist = 32;
            for (CreatorEntity c : mc.level.getEntitiesOfClass(CreatorEntity.class, mc.player.getBoundingBox().inflate(32),
                    x -> x.getState() == CreatorEntity.CHASE)) dist = Math.min(dist, c.distanceTo(mc.player));
            float amp = (float) (0.35 + 0.65 * (1.0 - dist / 32.0));
            double t = System.nanoTime() / 1.0e9;
            e.setRoll(e.getRoll() + (float) (Math.sin(t * 23) + 0.6 * Math.sin(t * 37.3)) * 0.45F * amp);
            e.setPitch(e.getPitch() + (float) (Math.sin(t * 29 + 1) + 0.5 * Math.sin(t * 41.7)) * 0.25F * amp);
            e.setYaw(e.getYaw() + (float) Math.sin(t * 31 + 2) * 0.2F * amp);
        }
    }

    private ClientEvents() {}
}
