package com.thecreator;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Vanilla-block recreation of the dream room (dark, blue-tinted by the dream shader). Tweak freely. */
public final class DreamRoom {
    public static final ResourceKey<Level> DIM = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(TheCreatorMod.ID, "dream"));
    public static final int FLOOR_Y = 64;
    public static final double PLAYER_X = 0.5, PLAYER_Y = FLOOR_Y + 1, PLAYER_Z = -6.5;
    public static final double CREATOR_X = 0.5, CREATOR_Y = FLOOR_Y + 1, CREATOR_Z = 5.5;

    private static void set(ServerLevel l, int x, int y, int z, BlockState s) { l.setBlock(new BlockPos(x, y, z), s, 2); }
    private static void set(ServerLevel l, int x, int y, int z, Block b) { set(l, x, y, z, b.defaultBlockState()); }

    public static void build(ServerLevel l) {
        for (int x = -8; x <= 8; x++) for (int z = -8; z <= 8; z++) for (int y = FLOOR_Y; y <= FLOOR_Y + 7; y++) {
            boolean wall = Math.abs(x) == 8 || Math.abs(z) == 8;
            Block b = Blocks.AIR;
            if (y == FLOOR_Y) b = ((x + z) & 1) == 0 ? Blocks.SPRUCE_PLANKS : Blocks.DARK_OAK_PLANKS;
            else if (y == FLOOR_Y + 7) b = Blocks.DARK_OAK_PLANKS;
            else if (wall) b = Blocks.DARK_OAK_PLANKS;
            set(l, x, y, z, b);
        }
        for (int z = -5; z <= 5; z++) for (int y = FLOOR_Y + 1; y <= FLOOR_Y + 4; y++) set(l, -7, y, z, Blocks.BOOKSHELF);   // library wall
        for (int z = -6; z <= -2; z++) set(l, 7, FLOOR_Y + 1, z, Blocks.SMOOTH_STONE);                                        // kitchen counters
        set(l, 7, FLOOR_Y + 1, 0, Blocks.BLAST_FURNACE.defaultBlockState().setValue(net.minecraft.world.level.block.BlastFurnaceBlock.FACING, Direction.WEST));
        set(l, 7, FLOOR_Y + 1, 2, Blocks.CAULDRON);
        set(l, 7, FLOOR_Y + 1, 4, Blocks.IRON_BLOCK);
        set(l, 7, FLOOR_Y + 2, 4, Blocks.IRON_BLOCK);
        set(l, 7, FLOOR_Y + 3, -4, Blocks.GLASS_PANE);                                                                         // wall screen
        set(l, -3, FLOOR_Y + 1, -2, Blocks.SPRUCE_FENCE);                                                                      // little table
        set(l, -3, FLOOR_Y + 2, -2, Blocks.SPRUCE_PRESSURE_PLATE);
        set(l, 0, FLOOR_Y + 6, 0, Blocks.PINK_STAINED_GLASS);                                                                  // ceiling lantern
        set(l, 0, FLOOR_Y + 5, 0, Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 7));
    }

    private DreamRoom() {}
}
