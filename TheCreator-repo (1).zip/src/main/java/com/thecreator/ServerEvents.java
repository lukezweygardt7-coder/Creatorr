package com.thecreator;

import com.mojang.brigadier.Command;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ServerEvents {
    private static final int DREAM_DAY = 5, COUNTDOWN_DAYS = 7, DREAM_TICKS = 330;
    private static final Pattern NUMBER = Pattern.compile("\\d+");
    private static final Pattern NAME = Pattern.compile("\\bcreator\\b");
    private static final Pattern HOUSE = Pattern.compile("\\bbuild me\\b.*\\bhouse\\b");
    private static final Pattern ITEM_REQ = Pattern.compile("\\b(give|make) me\\b");
    private static final Set<String> FILLER = Set.of("can", "you", "give", "make", "me", "please", "some", "a", "an", "the", "of", "creator");

    private final Random rng = new Random();
    private record Light(ResourceKey<Level> dim, BlockPos pos) {}
    private final Map<UUID, Light> lights = new HashMap<>();
    private static class Dream { ResourceKey<Level> dim; Vec3 pos; float yaw; int ticks = DREAM_TICKS; }
    private final Map<UUID, Dream> dreams = new HashMap<>();

    // After day zero he hunts the player constantly, with a 5-minute break now and then.
    private static final long BREAK_TICKS = 20L * 60 * 5;
    private static class Hunt { long chaseStart = -1, breakUntil = 0, chaseLen; }
    private final Map<UUID, Hunt> hunts = new HashMap<>();
    private final Map<UUID, Boolean> chasing = new HashMap<>();

    private void huntTick(ServerPlayer p, CreatorData d, int days, long t) {
        ServerLevel lv = (ServerLevel) p.level();
        if ((days == 0 || d.satisfaction <= 0F) && lv.dimension() != DreamRoom.DIM && !dreams.containsKey(p.getUUID()) && !p.isSpectator() && !p.isSleeping()) {
            Hunt h = hunts.computeIfAbsent(p.getUUID(), k -> new Hunt());
            if (t >= h.breakUntil) {
                if (h.chaseStart < 0) { h.chaseStart = t; h.chaseLen = 20L * 60 * (6 + rng.nextInt(10)); }   // chases last 6-15 minutes
                if (t - h.chaseStart > h.chaseLen) {                                                          // then a 5-minute rest
                    h.chaseStart = -1; h.breakUntil = t + BREAK_TICKS;
                    if (d.satisfaction <= 0F) d.addSatisfaction(0.1F);                                          // he calms a little during the rest
                    lv.getEntitiesOfClass(CreatorEntity.class, p.getBoundingBox().inflate(160), c -> c.getState() == CreatorEntity.CHASE)
                      .forEach(c -> c.vanish(false));
                } else if (lv.getEntitiesOfClass(CreatorEntity.class, p.getBoundingBox().inflate(128)).isEmpty()) {
                    CreatorEntity.spawnBehind(lv, p, CreatorEntity.CHASE);
                }
            }
        }
        boolean now = !lv.getEntitiesOfClass(CreatorEntity.class, p.getBoundingBox().inflate(48), c -> c.getState() == CreatorEntity.CHASE).isEmpty();
        if (chasing.getOrDefault(p.getUUID(), false) != now) { chasing.put(p.getUUID(), now); Net.sendChase(p, now); }   // drives chase shader + shake
    }

    // ------------------------------------------------ chat
    @SubscribeEvent
    public void onChat(ServerChatEvent e) {
        ServerPlayer p = e.getPlayer();
        String msg = e.getRawText().toLowerCase(Locale.ROOT);
        if (!(p.level() instanceof ServerLevel lv) || lv.dimension() == DreamRoom.DIM) return;
        List<CreatorEntity> near = lv.getEntitiesOfClass(CreatorEntity.class, p.getBoundingBox().inflate(32), c -> c.isAlive());
        CreatorEntity c = near.isEmpty() ? null : near.get(0);

        if (NAME.matcher(msg).find()) {                       // calling his name: he appears behind you
            if (c == null) {
                CreatorEntity n = CreatorEntity.spawnBehind(lv, p, CreatorEntity.IDLE);
                n.playVoice(TheCreatorMod.NAME_CALL.get());
            }
            return;
        }
        if (c == null || c.getState() == CreatorEntity.DREAM || !c.isLookedAtBy(p)) return;   // he must be there, and you must look at him

        CreatorData d = CreatorData.get(lv.getServer());
        if (HOUSE.matcher(msg).find()) {
            if (d.houseBuilt || d.satisfaction < 0.15F || !HouseBuilder.start(lv, p, d)) c.playVoice(TheCreatorMod.NO.get());
            else { c.playVoice(TheCreatorMod.BUILD_ACK.get()); d.addSatisfaction(0.05F); }
            return;
        }
        if (ITEM_REQ.matcher(msg).find()) handleItem(p, c, d, msg);
    }

    private void handleItem(ServerPlayer p, CreatorEntity c, CreatorData d, String msg) {
        Matcher m = NUMBER.matcher(msg);
        int amount = m.find() ? Math.min(Integer.parseInt(m.group()), 100000) : 1;
        String stripped = msg.replaceAll("\\d+", " ");
        List<String> tok = new ArrayList<>();
        for (String t : stripped.split("[^a-z_:]+")) if (!t.isEmpty() && !FILLER.contains(t)) tok.add(t);
        Item item = null;
        outer:
        for (int len = 3; len >= 1; len--)
            for (int i = 0; i + len <= tok.size(); i++) {
                String cand = String.join("_", tok.subList(i, i + len));
                for (String c2 : new String[]{cand, cand.endsWith("s") ? cand.substring(0, cand.length() - 1) : cand}) {
                    ResourceLocation rl = ResourceLocation.tryParse(c2);
                    if (rl == null) continue;
                    Item it = BuiltInRegistries.ITEM.getOptional(rl).orElse(null);
                    if (it != null && it != Items.AIR) { item = it; break outer; }
                }
            }
        if (item == null || amount < 1) return;

        ItemTiers.Tier tier = ItemTiers.of(item);
        int cap = ItemTiers.cap(item, tier, d.satisfaction);
        boolean yes = amount <= cap;
        if (yes && tier != ItemTiers.Tier.BASIC && amount > cap / 2.0) {          // closer to his limit = more likely a refusal
            double refuse = 0.8 * (amount - cap / 2.0) / (cap / 2.0);
            yes = rng.nextDouble() >= refuse;
        }
        if (!yes) { c.playVoice(TheCreatorMod.NO.get()); d.addSatisfaction(-0.02F); return; }
        c.playVoice(TheCreatorMod.YES.get());
        d.addSatisfaction(0.02F);
        int left = amount;
        while (left > 0) {
            int n = Math.min(left, Math.max(1, item.getMaxStackSize()));
            ItemStack s = new ItemStack(item, n);
            if (!p.getInventory().add(s)) {
                ItemEntity ie = new ItemEntity(p.level(), p.getX(), p.getY() + 0.5, p.getZ(), s);
                p.level().addFreshEntity(ie);
            }
            left -= n;
        }
    }

    // ------------------------------------------------ house blocks
    @SubscribeEvent
    public void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getLevel() instanceof ServerLevel lv) || lv.dimension() != Level.OVERWORLD || !(e.getPlayer() instanceof ServerPlayer p)) return;
        CreatorData d = CreatorData.get(lv.getServer());
        if (!d.houseBuilt || e.getState().isAir() || !HouseBuilder.isHouseBlock(d, e.getPos())) return;
        if (!d.broken.add(e.getPos().asLong())) return;
        d.addSatisfaction(-0.03F);
        if (!d.speechDone && d.broken.size() >= 6) {
            d.speechDone = true;
            CreatorEntity.spawnBehind(lv, p, CreatorEntity.SPEAK_BREAK);     // appears behind you and gives the speech
        } else if (d.speechDone && d.satisfaction <= 0F && lv.getEntitiesOfClass(CreatorEntity.class, p.getBoundingBox().inflate(64)).isEmpty()) {
            CreatorEntity.spawnBehind(lv, p, CreatorEntity.CHASE);
        }
        d.setDirty();
    }

    // ------------------------------------------------ ticking
    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer s = e.getServer();
        ServerLevel ow = s.overworld();
        CreatorData d = CreatorData.get(s);
        long t = ow.getGameTime();
        HouseBuilder.tick(ow, d, t);

        if (t % 40 == 0) { int days = countdown(s, d); for (ServerPlayer p : s.getPlayerList().getPlayers()) Net.sendCountdown(p, days); }

        int daysLeft = countdown(s, d);
        for (ServerPlayer p : new ArrayList<>(s.getPlayerList().getPlayers())) {
            if (t % 2 == 0) heldLight(p);
            if (t % 20 == 0) huntTick(p, d, daysLeft, t);
            Dream dr = dreams.get(p.getUUID());
            if (dr != null) { if (--dr.ticks <= 0) endDream(s, p, dr, d); }
            else if (!d.dreamDone && p.level().dimension() == Level.OVERWORLD && d.bookRead && p.isSleeping() && p.getSleepTimer() >= 60
                    && ow.getDayTime() / 24000L - d.startDay >= DREAM_DAY) startDream(s, p, d);
        }
    }

    public static int countdown(MinecraftServer s, CreatorData d) {
        if (!d.bookRead || d.startDay < 0) return -1;                      // hidden until the README is read
        long day = s.overworld().getDayTime() / 24000L - d.startDay;       // overworld clock: other dimensions can never reset it
        return (int) Math.max(0, COUNTDOWN_DAYS - day);
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        MinecraftServer s = p.server;
        CreatorData d = CreatorData.get(s);
        if (!d.chestPlaced) placeStartChest(s, d);
        Net.sendCountdown(p, countdown(s, d));
        chasing.put(p.getUUID(), false);
        Net.sendChase(p, false);
        if (p.level().dimension() == DreamRoom.DIM && !dreams.containsKey(p.getUUID())) {      // stuck in the dream after a restart
            BlockPos sp = p.getRespawnPosition() != null ? p.getRespawnPosition() : s.overworld().getSharedSpawnPos();
            p.teleportTo(s.overworld(), sp.getX() + 0.5, sp.getY(), sp.getZ() + 0.5, 0F, 0F);
        }
    }

    /** Bonus-chest style starter chest at spawn: vanilla bonus loot, one torch swapped for a redstone torch, plus the README. */
    private void placeStartChest(MinecraftServer s, CreatorData d) {
        ServerLevel ow = s.overworld();
        BlockPos sp = ow.getSharedSpawnPos();
        int x = sp.getX() + 2, z = sp.getZ();
        BlockPos pos = new BlockPos(x, ow.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z);
        ow.setBlock(pos, Blocks.CHEST.defaultBlockState(), 3);
        if (ow.getBlockEntity(pos) instanceof ChestBlockEntity chest) {
            chest.setLootTable(new ResourceLocation("chests/spawn_bonus_chest"), ow.getRandom().nextLong());
            chest.unpackLootTable(null);
            boolean hasBook = false, swapped = false;
            for (int i = 0; i < chest.getContainerSize(); i++) {
                ItemStack st = chest.getItem(i);
                if (!swapped && st.is(Items.TORCH)) { chest.setItem(i, new ItemStack(Items.REDSTONE_TORCH, st.getCount())); swapped = true; }
                if (st.is(Items.WRITTEN_BOOK)) hasBook = true;
            }
            if (!hasBook) for (int i = 0; i < chest.getContainerSize(); i++)
                if (chest.getItem(i).isEmpty()) { chest.setItem(i, RuleBookModifier.makeBook()); break; }
            chest.setChanged();
        }
        d.chestPlaced = true;
        d.setDirty();
    }

    /** Reading the README starts the 7-day countdown and makes it appear on screen. */
    @SubscribeEvent
    public void onUse(PlayerInteractEvent.RightClickItem e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack st = e.getItemStack();
        if (!st.is(Items.WRITTEN_BOOK) || st.getTag() == null || !"README".equals(st.getTag().getString("title"))) return;
        CreatorData d = CreatorData.get(p.server);
        if (d.bookRead) return;
        d.bookRead = true;
        d.startDay = p.server.overworld().getDayTime() / 24000L;
        d.setDirty();
        Net.sendCountdown(p, countdown(p.server, d));
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { clearLight(e.getEntity().getServer(), e.getEntity().getUUID()); }

    // ------------------------------------------------ held torch glow
    private void heldLight(ServerPlayer p) {
        boolean torch = p.getMainHandItem().is(Items.TORCH) || p.getOffhandItem().is(Items.TORCH)
                || p.getMainHandItem().is(Items.SOUL_TORCH) || p.getOffhandItem().is(Items.SOUL_TORCH);
        ServerLevel lv = (ServerLevel) p.level();
        Light want = torch ? new Light(lv.dimension(), BlockPos.containing(p.getX(), p.getEyeY(), p.getZ())) : null;
        Light old = lights.get(p.getUUID());
        if (Objects.equals(old, want)) return;
        clearLight(p.server, p.getUUID());
        if (want != null && lv.getBlockState(want.pos()).isAir()) {
            lv.setBlock(want.pos(), Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 13), 3);
            lights.put(p.getUUID(), want);
        }
    }

    private void clearLight(MinecraftServer s, UUID id) {
        Light old = lights.remove(id);
        if (old == null || s == null) return;
        ServerLevel lv = s.getLevel(old.dim());
        if (lv != null && lv.getBlockState(old.pos()).is(Blocks.LIGHT)) lv.setBlock(old.pos(), Blocks.AIR.defaultBlockState(), 3);
    }

    // ------------------------------------------------ dream (day 5 sleep)
    private void startDream(MinecraftServer s, ServerPlayer p, CreatorData d) {
        ServerLevel dream = s.getLevel(DreamRoom.DIM);
        if (dream == null) return;
        if (!d.dreamRoomBuilt) { DreamRoom.build(dream); d.dreamRoomBuilt = true; d.setDirty(); }
        Dream dr = new Dream();
        dr.dim = p.level().dimension(); dr.pos = p.position(); dr.yaw = p.getYRot();
        dreams.put(p.getUUID(), dr);
        p.stopSleeping();
        p.teleportTo(dream, DreamRoom.PLAYER_X, DreamRoom.PLAYER_Y, DreamRoom.PLAYER_Z, 0F, 0F);
        p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false, false));
        CreatorEntity c = TheCreatorMod.CREATOR.get().create(dream);
        c.moveTo(DreamRoom.CREATOR_X, DreamRoom.CREATOR_Y, DreamRoom.CREATOR_Z, 0F, 0F);   // the dream pose turns him around to face you
        c.yHeadRot = 0F; c.yBodyRot = 0F;
        c.setState(CreatorEntity.DREAM);
        c.setNoAi(true);
        c.setNoGravity(true);
        dream.addFreshEntity(c);
        c.playVoice(TheCreatorMod.DREAM_SPEECH.get());
    }

    private void endDream(MinecraftServer s, ServerPlayer p, Dream dr, CreatorData d) {
        dreams.remove(p.getUUID());
        ServerLevel dream = s.getLevel(DreamRoom.DIM), back = s.getLevel(dr.dim);
        if (dream != null) dream.getEntitiesOfClass(CreatorEntity.class, p.getBoundingBox().inflate(64)).forEach(c -> c.discard());
        if (back == null) back = s.overworld();
        p.teleportTo(back, dr.pos.x, dr.pos.y, dr.pos.z, dr.yaw, 0F);
        ServerLevel ow = s.overworld();
        ow.setDayTime((ow.getDayTime() / 24000L + 1L) * 24000L);          // you wake up the next morning
        p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false, false));
        d.dreamDone = true;
        d.setDirty();
    }

    // ------------------------------------------------ test commands (op only)
    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("creator").requires(src -> src.hasPermission(2))
            .then(Commands.literal("spawn").executes(ctx -> { ServerPlayer p = ctx.getSource().getPlayerOrException();
                CreatorEntity.spawnBehind((ServerLevel) p.level(), p, CreatorEntity.IDLE); return Command.SINGLE_SUCCESS; }))
            .then(Commands.literal("chase").executes(ctx -> { ServerPlayer p = ctx.getSource().getPlayerOrException();
                CreatorEntity.spawnBehind((ServerLevel) p.level(), p, CreatorEntity.CHASE); return Command.SINGLE_SUCCESS; }))
            .then(Commands.literal("speech").executes(ctx -> { ServerPlayer p = ctx.getSource().getPlayerOrException();
                CreatorEntity.spawnBehind((ServerLevel) p.level(), p, CreatorEntity.SPEAK_BREAK); return Command.SINGLE_SUCCESS; }))
            .then(Commands.literal("dream").executes(ctx -> { ServerPlayer p = ctx.getSource().getPlayerOrException();
                startDream(p.server, p, CreatorData.get(p.server)); return Command.SINGLE_SUCCESS; }))
            .then(Commands.literal("reset").executes(ctx -> { MinecraftServer s = ctx.getSource().getServer(); CreatorData d = CreatorData.get(s);
                d.startDay = -1; d.bookRead = false; d.houseBuilt = false; d.speechDone = false; d.dreamDone = false;
                d.builtLayers = 0; d.broken.clear(); d.satisfaction = 0.5F; d.setDirty(); return Command.SINGLE_SUCCESS; })));
    }
}
