package com.thecreator;

/** Plain static holder, safe to touch from both sides. */
public final class ClientState {
    public static volatile int countdown = -1;
    public static volatile boolean chasing = false;
    private ClientState() {}
}
