package com.thecreator;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.Supplier;

/** Adds the README book to the bonus chest. */
public class RuleBookModifier extends LootModifier {
    public static final Supplier<Codec<RuleBookModifier>> CODEC =
            Suppliers.memoize(() -> RecordCodecBuilder.create(i -> codecStart(i).apply(i, RuleBookModifier::new)));

    // Pages 1-3 come from your video. TODO: pages 4 and 5 (page 4 is Morse code in the video, page 5 was never shown).
    public static final List<String> PAGES = List.of(
            "Need help?\n\nCall its name.\n\nIt will appear.\n\nAsk, and it will help.\n\nAsk, and it will gather.\n\nAsk, and it will protect.\n\nUnless...",
            "WARNING:\nThis build is NOT intended for public use, only for the testers of the \u2588\u2588\u2588\u2588 Company.\n\nUnauthorized use of this build will result in immediate termination or worse.\n\nReturn the file...",
            "\u2588\u2588\u2588\u2588\u2588\u2588\n\nWILL START IN\n\n7 DAYS...\n\nName - Creator",
            "TODO page 4 (Morse code)",
            "TODO page 5");

    public static ItemStack makeBook() {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();
        tag.putString("title", "README");
        tag.putString("author", "???");
        tag.putBoolean("resolved", true);
        ListTag pages = new ListTag();
        for (String p : PAGES) pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(p))));
        tag.put("pages", pages);
        return book;
    }

    public RuleBookModifier(LootItemCondition[] conditions) { super(conditions); }

    @Override
    protected @NotNull ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext ctx) {
        if (ctx.getQueriedLootTableId().equals(new ResourceLocation("minecraft", "chests/spawn_bonus_chest"))) {
            loot.add(makeBook());
        }
        return loot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() { return CODEC.get(); }
}
