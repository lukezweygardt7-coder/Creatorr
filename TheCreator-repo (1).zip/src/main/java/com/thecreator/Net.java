package com.thecreator;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(TheCreatorMod.ID, "main"), () -> V, V::equals, V::equals);

    public static void init() {
        CH.registerMessage(0, Countdown.class, Countdown::encode, Countdown::decode, Countdown::handle);
        CH.registerMessage(1, Chase.class, Chase::encode, Chase::decode, Chase::handle);
    }

    public static void sendCountdown(ServerPlayer p, int days) {
        CH.send(PacketDistributor.PLAYER.with(() -> p), new Countdown(days));
    }

    public static void sendChase(ServerPlayer p, boolean on) {
        CH.send(PacketDistributor.PLAYER.with(() -> p), new Chase(on));
    }

    public record Chase(boolean on) {
        static void encode(Chase m, FriendlyByteBuf b) { b.writeBoolean(m.on); }
        static Chase decode(FriendlyByteBuf b) { return new Chase(b.readBoolean()); }
        static void handle(Chase m, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> ClientState.chasing = m.on);
            ctx.get().setPacketHandled(true);
        }
    }

    public record Countdown(int days) {
        static void encode(Countdown m, FriendlyByteBuf b) { b.writeInt(m.days); }
        static Countdown decode(FriendlyByteBuf b) { return new Countdown(b.readInt()); }
        static void handle(Countdown m, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> ClientState.countdown = m.days);
            ctx.get().setPacketHandled(true);
        }
    }
}
